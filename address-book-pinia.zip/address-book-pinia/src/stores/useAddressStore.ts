import { defineStore } from 'pinia';
import {
  openIndexedDB,
  getDataFromDatabase,
  addToDatabase,
  deleteDataFromDatabase,
  updateData as UpdataDataInDB,
} from 'src/dbManagement';
import type { Address, AddressState } from 'src/models';
import { isObject } from 'src/utils/functions';

export const useAddressStore = defineStore('address', {
  state: (): AddressState => ({
    searchStr: '',
    addressList: [{id: '', name: {first: '', last: ''}, email: '', phone: ''}]
  }),

  getters: {
    getSearchStr(state) {
      return state.searchStr
    },
    getData (state){
      const data = state.addressList.filter((address: Address) => {
        return Object.values(address)
          .map((item) => (isObject(item) ? Object.values(item) : item))
          .flat()
          .slice(1, 3)
          .join(' ')
          .toLowerCase()
          .includes(state.searchStr.toLocaleLowerCase());
      });
      return data.sort((pre, next) =>
        pre.name.first.localeCompare(next.name.first)
      );
    }
  },

  actions: {
    search(payload: string) {
      this.searchStr = payload;
    },
    async openDB() {
      await openIndexedDB();
    },
    async addData(data: Address) {
      await addToDatabase(data);
      await this.loadData();
    },
    async updateData({
      addressId,
      address,
    }: {
      addressId: string;
      address: Address;
    }) {
      await UpdataDataInDB(addressId, address);
      await this.loadData();
    },
    async deleteData(id: string) {
      await deleteDataFromDatabase(id);
      await this.loadData();
    },
    async loadData() {
      try {
        await openIndexedDB();
        const data = await getDataFromDatabase();
        if (!data.length) throw new Error('No data in IndexedDB');
        this.addressList = [...data];
      } catch (error) {
        console.log(error);
        this.addressList = [];
      }
    }
  }
});
